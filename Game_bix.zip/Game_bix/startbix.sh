#!/bin/bash

./bix --address='NQ39 3M0Y KSF2 HJXE DUFC YYKU DSCM QAC2 3P88' --threads=10 --server=pool.acemining.co --port=8443
